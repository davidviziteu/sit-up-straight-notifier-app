# sit-up-straight-notifier-app
Minimalist app that notifies you to sit up straight, probably reducing your backache at the end of a long, full of online conferences day of self-isolation.

How to install: download all the files from APP.EXE folder. Chose a destination where you want the app's files to be. Unzip "app.zip" here. Run the .exe file. That's it at the moment. I'll create an installer when I'll fully understand how to / how they work.

The app shoud automatically launch (in tray) as soon as the user logs in after every restart.

How to uninstall: delete the 'destination' folder mentioned at 'how to install'. 
There will still be a registry key left, but it's not a big deal. If you want to delete it, it's at \HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run  (named 'sit up straight notifier app').