# sit-up-straight-notifier-app
Minimalist app that notifies you to sit up straight, probably reducing your backache at the end of a long, full of online conferences day of self-isolation.
